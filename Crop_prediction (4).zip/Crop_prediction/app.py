# Import essential libraries 
from flask import Flask, render_template, request, Markup
import numpy as np
import requests
import pickle
import json
import pandas as pd
weather_api_key = "9d7cde1f6d07ec55650544be1631307e"
#-----------------------------------------------------------
# Trained Random Forest model
crop_recommendation_model_path = 'trainedmodel\RandomForest.pkl'
crop_recommendation_model = pickle.load(
    open(crop_recommendation_model_path, 'rb'))
#-----------------------------------------------------------
#Function for fetching current humidity and temperature values
def weather_fetch(city_name):
    """
    Fetch and returns the temperature and humidity of a city
    :params: city_name
    :return: temperature, humidity
    """
    api_key = weather_api_key
    base_url = "http://api.openweathermap.org/data/2.5/weather?"

    complete_url = base_url + "appid=" + api_key + "&q=" + city_name
    response = requests.get(complete_url)
    x = response.json()

    if x["cod"] != "404":
        y = x["main"]
        temperature = round((y["temp"] - 273.15), 2)
        humidity = y["humidity"]
        return temperature, humidity
    else:
        return None
    
#-----------------------------------------------------------
#-----------------------FLASK APP FOR RUNNING APPLICATION--------------------
app = Flask(__name__)

@ app.route("/")
def home():
    return render_template('index.html')
@ app.route('/crop-recommend')
def crop_recommend():
    return render_template('crop.html')
@ app.route('/crop-predict', methods=['POST'])
def crop_prediction():
    if request.method == 'POST':
        city = request.form.get("city")
        ph = float(request.form['ph'])
        rainfall = float(request.form['rainfall'])
        state = request.form.get("state")
        city = request.form.get("city")
        #crops list
        crops = ['Adzuki Beans','Apple', 'Banana', 'Blackgram', 'Chick peas', 'Coconut', 'Coffee', 'Cotton', 'Grapes', 'Ground nut', 'Jute', 'Kidney Beans', 'Lentil', 'Maize', 'Mango', 'Millet', 'Moth Beans', 'Mungbean', 'Muskmelon', 'Orange', 'Papaya', 'Peas', 'Pigeon Peas', 'Pomegranate', 'Rice','Rubber', 'Sugarcane', 'Tea', 'Tobacco', 'Watermelon', 'Wheat']
        if weather_fetch(city) != None:
            temperature, humidity = weather_fetch(city)
            data = np.array([[ temperature, humidity, ph, rainfall]])
            my_prediction = crop_recommendation_model.predict(data)
            final_prediction = crops[my_prediction[0]]
            return render_template('crop_result.html', prediction=final_prediction,city = city,state = state)

        else:
            return render_template('try_again.html')
@app.route('/crop-fertilizer')
def crop_fertilization():
    return render_template('fertilizer.html')
@app.route('/fertilizer-recommendation',methods = ['POST'])
def fert_recommend():
    #accessing the data
    fer = pd.read_csv('Fertilizer_Data.csv')
    crop_name = str(request.form['cropname'])
    N = int(request.form['nitrogen'])
    P = int(request.form['phosphorous'])
    K = int(request.form['pottasium'])
    x = fer[fer['Crop'] == crop_name]
    if x['N'].item() >= N:
        Nkey = "Low"
    else:
        Nkey = "High"
    if x['P'].item() >= P:
        Pkey = "Low"
    else:
        Pkey = "High"
    if x['K'].item() >= K:
        Kkey = "Low"
    else:
        Kkey = "High"
    Nval = x['N'].item()
    Pval = x['P'].item()
    Kval = x['K'].item()
    return render_template('fertilizer_result.html',Nkey = Nkey,Nval = Nval,Pkey = Pkey,Pval = Pval,Kkey = Kkey,Kval= Kval,crop_name = crop_name)
@ app.route('/contact-us')
def contact_us():
    return render_template('contact.html')

app.run()